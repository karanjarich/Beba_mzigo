<?php
	
		$price = 7;
		$stock = 8;
		$sql = $price+ $stock;
		echo $sql;
?>
<script>  
      $(document).ready(function(){  
           $('#product_no').keyup(function(){  
                var search = $('#product_no').val();  
                if(search != '')  
                {  
                     $.ajax({  
                          url:"test.php",  
                          method:"POST",  
                          data:{search:search},
						  dataType:"Text",
                          success:function(data)  
                          {  
                             //$('#results').html(data);  // this works
							 document.getElementById('price').value=data;
                          }  
                     });  
                }  
 
           });
	function EditSales(){
		var sales = $("#sales").val(); 
		$.ajax({  
                          url:"sales_save.php",  
                          method:"POST",  
                          data:{sales:sales},
						  dataType:"Text",
						  async:false,
                          success:function(data)  
                          {  
                             $('#sales_product').html(data);  // this works
							 //alert(sales);
							  }  
                     });  
	}
	
    function EditData(){
		var sales = $("#sales").val(); 
		$.ajax({  
                          url:"sales_save.php",  
                          method:"POST",  
                          data:{sales:sales},
						  dataType:"Text",
						  async:false,
                          success:function(data)  
                          {  
                             $('#sales_product').html(data);  // this works
							 //alert(sales);
							  }  
                     });  
	}
	function DisplayData(){
		var sales = $("#sales").val(); 
		$.ajax({  
                          url:"sales_save.php",  
                          method:"POST",  
                          data:{sales:sales},
						  dataType:"Text",
						  async:false,
                          success:function(data)  
                          {  
                             $('#sales_product').html(data);  // this works
							 //alert(sales);
							  }  
                     });  
	}
		 $("#add").click(function(){
						var product_no = $("#product_no").val();  
						var quantity = $("#quantity").val(); 
						var price = $("#price").val();
						var sales = $("#sales").val(); 
						var id=sales+product_no;
						// Returns successful data submission message when the entered information is stored in database.
					//	var dataString :{ product_no: product_no,quantity:quantity ,sales:sales,price: price};
						if(product_no==''||quantity==''||sales==''||price==''||id=='')
						{
						   alert("Please Fill All Fields");
						}
						else
						{
						// AJAX Code To Submit Form.
						$.ajax({
						type: "POST",
						url: "sales_save.php",
						data:{ product_no: product_no,quantity:quantity ,sales:sales,price: price,id:id},
						cache: false,
						success: function(result){
							//retrieve the data that has been saved in the database bearing the sales number
							  $("#product_no").val('');
							  $("#quantity").val(''); 
						      $("#price").val('');
							   DisplayData();
						  	}
						});
						}
						return false;
						});	  
		});  
		          
 </script>

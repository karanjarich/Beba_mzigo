<?php
 $sentence="testing was awesome";
 $dir=str_replace(' ','', $sentence);
 echo( $dir);
 ?>

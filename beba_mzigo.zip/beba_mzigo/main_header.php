<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="bird.jpg" alt="logo" style="width:40px;">
  </a>
  
  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="registration_owner.php">Register Owner</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="registeration.php">Register User</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="index.php">Login</a>
    </li>
  </ul>
</nav>